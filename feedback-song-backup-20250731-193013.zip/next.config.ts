import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  experimental: {
    serverActions: {
      allowedOrigins: ["localhost:3000"]
    }
  },
  // Disable strict mode in development to prevent double renders that cause WaveSurfer issues
  reactStrictMode: false
};

export default nextConfig;