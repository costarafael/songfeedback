export interface Song {
  id: string
  title: string
  artist?: string
  file_url: string
  duration?: number
  upload_date: string
  listen_count: number
}

export interface Reaction {
  id: string
  song_id: string
  reaction_type: 'love' | 'like' | 'dislike' | 'angry'
  timestamp: number
  session_id: string
  created_at: string
}

export interface ListeningSession {
  id: string
  song_id: string
  session_id: string
  started_at: string
  completed: boolean
}

export interface ReactionStats {
  reaction_type: 'love' | 'like' | 'dislike' | 'angry'
  count: number
  timestamps: number[]
}