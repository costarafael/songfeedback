import { supabase } from '@/lib/supabase'
import { Song, Reaction, ReactionStats } from '@/lib/types'
import Link from 'next/link'
import { ArrowLeft } from 'lucide-react'
import StatsCharts from '@/components/Admin/StatsCharts'

async function getSongWithStats(songId: string) {
  // Get song data
  const { data: song, error: songError } = await supabase
    .from('songs')
    .select('*')
    .eq('id', songId)
    .single()

  if (songError) {
    return null
  }

  // Get reactions
  const { data: reactions, error: reactionsError } = await supabase
    .from('reactions')
    .select('*')
    .eq('song_id', songId)
    .order('timestamp')

  if (reactionsError) {
    console.error('Error fetching reactions:', reactionsError)
  }

  // Get listening sessions count
  const { count: sessionCount } = await supabase
    .from('listening_sessions')
    .select('*', { count: 'exact', head: true })
    .eq('song_id', songId)

  return {
    song: song as Song,
    reactions: reactions as Reaction[] || [],
    sessionCount: sessionCount || 0
  }
}

function processReactionStats(reactions: Reaction[]): ReactionStats[] {
  const statsMap = new Map<string, ReactionStats>()

  reactions.forEach(reaction => {
    if (!statsMap.has(reaction.reaction_type)) {
      statsMap.set(reaction.reaction_type, {
        reaction_type: reaction.reaction_type,
        count: 0,
        timestamps: []
      })
    }
    
    const stats = statsMap.get(reaction.reaction_type)!
    stats.count++
    stats.timestamps.push(reaction.timestamp)
  })

  return Array.from(statsMap.values())
}

export default async function StatsPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const data = await getSongWithStats(id)
  
  if (!data) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-xl">Música não encontrada</div>
      </div>
    )
  }

  const { song, reactions, sessionCount } = data
  const reactionStats = processReactionStats(reactions)
  const totalReactions = reactions.length

  const reactionEmojis = {
    love: '❤️',
    like: '👍',
    dislike: '👎',
    angry: '😠'
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        <Link
          href="/admin"
          className="flex items-center space-x-2 text-blue-600 hover:text-blue-800 mb-8"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Voltar ao Admin</span>
        </Link>

        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold mb-2">Estatísticas: {song.title}</h1>
            {song.artist && (
              <p className="text-xl text-gray-600">por {song.artist}</p>
            )}
          </div>

          {/* Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div className="bg-white rounded-lg shadow-lg p-6 text-center">
              <h3 className="text-lg font-semibold text-gray-700">Reproduções</h3>
              <p className="text-3xl font-bold text-blue-600">{song.listen_count}</p>
            </div>
            
            <div className="bg-white rounded-lg shadow-lg p-6 text-center">
              <h3 className="text-lg font-semibold text-gray-700">Sessões</h3>
              <p className="text-3xl font-bold text-green-600">{sessionCount}</p>
            </div>
            
            <div className="bg-white rounded-lg shadow-lg p-6 text-center">
              <h3 className="text-lg font-semibold text-gray-700">Total Reações</h3>
              <p className="text-3xl font-bold text-purple-600">{totalReactions}</p>
            </div>
            
            <div className="bg-white rounded-lg shadow-lg p-6 text-center">
              <h3 className="text-lg font-semibold text-gray-700">Duração</h3>
              <p className="text-3xl font-bold text-gray-600">
                {song.duration ? `${Math.floor(song.duration / 60)}:${(song.duration % 60).toString().padStart(2, '0')}` : 'N/A'}
              </p>
            </div>
          </div>

          {/* Reaction Breakdown */}
          <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
            <h2 className="text-2xl font-semibold mb-6">Distribuição de Reações</h2>
            
            {reactionStats.length === 0 ? (
              <p className="text-gray-600 text-center py-8">Nenhuma reação registrada ainda</p>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {reactionStats.map((stat) => {
                  const percentage = totalReactions > 0 ? (stat.count / totalReactions * 100).toFixed(1) : '0'
                  
                  return (
                    <div key={stat.reaction_type} className="text-center p-4 border rounded-lg">
                      <div className="text-4xl mb-2">
                        {reactionEmojis[stat.reaction_type]}
                      </div>
                      <div className="text-2xl font-bold">{stat.count}</div>
                      <div className="text-sm text-gray-600">{percentage}%</div>
                      <div className="text-xs text-gray-500 capitalize">
                        {stat.reaction_type === 'love' ? 'Amei' :
                         stat.reaction_type === 'like' ? 'Gostei' :
                         stat.reaction_type === 'dislike' ? 'Não gostei' : 'Descontente'}
                      </div>
                    </div>
                  )
                })}
              </div>
            )}
          </div>

          {/* Timeline Visualization */}
          {reactions.length > 0 && (
            <div className="bg-white rounded-lg shadow-lg p-6">
              <h2 className="text-2xl font-semibold mb-6">Timeline de Reações</h2>
              <StatsCharts 
                reactions={reactions} 
                duration={song.duration || 0}
                reactionStats={reactionStats}
              />
            </div>
          )}

          {/* Recent Reactions */}
          {reactions.length > 0 && (
            <div className="bg-white rounded-lg shadow-lg p-6 mt-8">
              <h2 className="text-2xl font-semibold mb-6">Reações Recentes</h2>
              <div className="space-y-2">
                {reactions.slice(-10).reverse().map((reaction, index) => (
                  <div key={reaction.id} className="flex items-center justify-between py-2 border-b border-gray-100">
                    <div className="flex items-center space-x-3">
                      <span className="text-xl">{reactionEmojis[reaction.reaction_type]}</span>
                      <span className="capitalize">
                        {reaction.reaction_type === 'love' ? 'Amei' :
                         reaction.reaction_type === 'like' ? 'Gostei' :
                         reaction.reaction_type === 'dislike' ? 'Não gostei' : 'Descontente'}
                      </span>
                    </div>
                    <div className="text-sm text-gray-600">
                      {Math.floor(reaction.timestamp / 60)}:{(Math.floor(reaction.timestamp % 60)).toString().padStart(2, '0')}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}