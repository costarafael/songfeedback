'use client'

import { useState } from 'react'
import { Heart, ThumbsUp, ThumbsDown, Angry } from 'lucide-react'

interface ReactionButtonsProps {
  onReaction: (type: 'love' | 'like' | 'dislike' | 'angry') => void
  disabled?: boolean
}

export default function ReactionButtons({ onReaction, disabled }: ReactionButtonsProps) {
  const [lastReaction, setLastReaction] = useState<string | null>(null)

  const handleReaction = (type: 'love' | 'like' | 'dislike' | 'angry') => {
    if (disabled) return
    
    onReaction(type)
    setLastReaction(type)
    
    // Reset animation after 500ms
    setTimeout(() => setLastReaction(null), 500)
  }

  const reactions = [
    {
      type: 'love' as const,
      icon: Heart,
      label: 'Amei',
      color: 'text-red-400 hover:text-red-500 dark:text-red-400 dark:hover:text-red-300'
    },
    {
      type: 'like' as const,
      icon: ThumbsUp,
      label: 'Gostei',
      color: 'text-green-400 hover:text-green-500 dark:text-green-400 dark:hover:text-green-300'
    },
    {
      type: 'dislike' as const,
      icon: ThumbsDown,
      label: 'Não gostei',
      color: 'text-yellow-400 hover:text-yellow-500 dark:text-yellow-400 dark:hover:text-yellow-300'
    },
    {
      type: 'angry' as const,
      icon: Angry,
      label: 'Descontente',
      color: 'text-orange-400 hover:text-orange-500 dark:text-orange-400 dark:hover:text-orange-300'
    }
  ]

  return (
    <div className="flex justify-center space-x-8 mt-6">
      {reactions.map(({ type, icon: Icon, label, color }) => (
        <button
          key={type}
          onClick={() => handleReaction(type)}
          disabled={disabled}
          className={`
            w-16 h-16 rounded-full flex items-center justify-center transition-all duration-200
            bg-background ${color}
            shadow-[8px_8px_20px_#46464635,-8px_-8px_20px_#ffffff60] 
            dark:shadow-[8px_8px_20px_#00000050,-8px_-8px_20px_#ffffff15]
            hover:shadow-[inset_8px_8px_20px_#46464635,inset_-8px_-8px_20px_#ffffff60]
            dark:hover:shadow-[inset_8px_8px_20px_#00000050,inset_-8px_-8px_20px_#ffffff15]
            hover:scale-105 active:scale-95
            disabled:text-muted-foreground/50 disabled:shadow-none disabled:cursor-not-allowed
            ${lastReaction === type ? 'animate-pulse scale-110 shadow-[inset_8px_8px_20px_#46464635,inset_-8px_-8px_20px_#ffffff60] dark:shadow-[inset_8px_8px_20px_#00000050,inset_-8px_-8px_20px_#ffffff15]' : ''}
          `}
          title={label}
        >
          <Icon className="w-7 h-7" />
        </button>
      ))}
    </div>
  )
}