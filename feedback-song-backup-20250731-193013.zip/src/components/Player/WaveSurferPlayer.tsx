'use client'

import { Play, Pause } from 'lucide-react'
import { useWaveSurfer } from '@/hooks/useWaveSurfer'

interface WaveSurferPlayerProps {
  audioUrl: string
  onTimeUpdate?: (currentTime: number) => void
  onDurationChange?: (duration: number) => void
}

export default function WaveSurferPlayer({ 
  audioUrl, 
  onTimeUpdate, 
  onDurationChange 
}: WaveSurferPlayerProps) {
  const {
    containerRef,
    isPlaying,
    isLoading,
    error,
    togglePlayPause
  } = useWaveSurfer({
    audioUrl,
    onTimeUpdate,
    onDurationChange
  })

  return (
    <div className="w-full max-w-[600px] bg-background rounded-2xl p-6 shadow-[inset_-16px_-12px_50px_#46464635,inset_0px_16px_36px_-12px_#ffffff50] dark:shadow-[inset_-16px_-12px_50px_#00000060,inset_0px_16px_36px_-12px_#ffffff20]">
      <div className="flex items-center space-x-6">
        <button
          onClick={togglePlayPause}
          disabled={isLoading || !!error}
          className="w-14 h-14 rounded-full flex items-center justify-center transition-all duration-200 flex-shrink-0
                     bg-background text-muted-foreground hover:text-foreground
                     shadow-[8px_8px_20px_#46464635,-8px_-8px_20px_#ffffff60] 
                     dark:shadow-[8px_8px_20px_#00000050,-8px_-8px_20px_#ffffff15]
                     hover:shadow-[inset_8px_8px_20px_#46464635,inset_-8px_-8px_20px_#ffffff60]
                     dark:hover:shadow-[inset_8px_8px_20px_#00000050,inset_-8px_-8px_20px_#ffffff15]
                     disabled:text-muted-foreground/50 disabled:shadow-none"
        >
          {isPlaying ? (
            <Pause className="w-6 h-6" />
          ) : (
            <Play className="w-6 h-6 ml-0.5" />
          )}
        </button>
        
        <div className="flex-1 min-w-0">
          {isLoading && (
            <div className="text-muted-foreground text-sm mb-3">Carregando áudio...</div>
          )}
          
          {error && (
            <div className="text-destructive text-sm mb-3">{error}</div>
          )}
          
          <div 
            ref={containerRef} 
            className="w-full rounded-xl p-3 
                       bg-background
                       shadow-[inset_8px_8px_20px_#46464635,inset_-8px_-8px_20px_#ffffff60]
                       dark:shadow-[inset_8px_8px_20px_#00000050,inset_-8px_-8px_20px_#ffffff15]" 
          />
        </div>
      </div>
    </div>
  )
}