'use client'

import { useState } from 'react'
import { Upload } from 'lucide-react'
import { useRouter } from 'next/navigation'

export default function UploadForm() {
  const [title, setTitle] = useState('')
  const [artist, setArtist] = useState('')
  const [file, setFile] = useState<File | null>(null)
  const [uploading, setUploading] = useState(false)
  const [message, setMessage] = useState('')
  const router = useRouter()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!file || !title) {
      setMessage('Por favor, preencha o título e selecione um arquivo')
      return
    }

    setUploading(true)
    setMessage('')

    try {
      // Prepare form data
      const formData = new FormData()
      formData.append('file', file)
      formData.append('title', title)
      formData.append('artist', artist)

      // Upload via API
      const response = await fetch('/api/upload', {
        method: 'POST',
        body: formData
      })

      const result = await response.json()

      if (!response.ok) {
        throw new Error(result.error || 'Erro no upload')
      }

      setMessage('Música enviada com sucesso!')
      setTitle('')
      setArtist('')
      setFile(null)
      
      // Reset form
      const form = e.target as HTMLFormElement
      form.reset()
      
      // Refresh page to show new song
      router.refresh()

    } catch (error) {
      console.error('Upload error:', error)
      setMessage(`Erro ao enviar música: ${error instanceof Error ? error.message : 'Erro desconhecido'}`)
    } finally {
      setUploading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Título da Música *
        </label>
        <input
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          placeholder="Digite o título da música"
          required
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Artista (opcional)
        </label>
        <input
          type="text"
          value={artist}
          onChange={(e) => setArtist(e.target.value)}
          className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          placeholder="Digite o nome do artista"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Arquivo de Áudio *
        </label>
        <div className="border-2 border-dashed border-gray-300 rounded-lg p-6">
          <input
            type="file"
            accept="audio/*"
            onChange={(e) => setFile(e.target.files?.[0] || null)}
            className="w-full"
            required
          />
          <div className="text-center mt-4">
            <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
            <p className="text-sm text-gray-600">
              Selecione um arquivo de áudio (MP3, WAV, etc.)
            </p>
            {file && (
              <p className="text-sm text-green-600 mt-2">
                Arquivo selecionado: {file.name}
              </p>
            )}
          </div>
        </div>
      </div>

      {message && (
        <div className={`p-3 rounded-lg ${
          message.includes('sucesso') 
            ? 'bg-green-100 text-green-700 border border-green-300' 
            : 'bg-red-100 text-red-700 border border-red-300'
        }`}>
          {message}
        </div>
      )}

      <button
        type="submit"
        disabled={uploading || !file || !title}
        className="w-full bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors"
      >
        {uploading ? 'Enviando...' : 'Enviar Música'}
      </button>
    </form>
  )
}